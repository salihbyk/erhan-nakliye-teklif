-- Eksik tabloları oluşturmak için SQL dosyası
-- Bu dosya phpMyAdmin'de çalıştırılabilir

USE nakliye_teklif;

-- 1. Additional costs tablosu
CREATE TABLE IF NOT EXISTS additional_costs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency ENUM('TL', 'USD', 'EUR') DEFAULT 'TL',
    is_additional BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_additional_costs_quote_id (quote_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Cost lists tablosu
CREATE TABLE IF NOT EXISTS cost_lists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    transport_mode_id INT,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode_id),
    INDEX idx_active (is_active),
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Email templates tablosu
CREATE TABLE IF NOT EXISTS email_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode_id INT NOT NULL,
    language VARCHAR(2) DEFAULT 'tr',
    currency VARCHAR(3) DEFAULT 'EUR',
    subject VARCHAR(255) NOT NULL,
    email_content TEXT NOT NULL,
    quote_content TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Transport images tablosu (eğer yoksa)
CREATE TABLE IF NOT EXISTS transport_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode VARCHAR(50) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    image_name VARCHAR(255) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Payments tablosu (eğer yoksa)
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'TL',
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    transaction_id VARCHAR(255),
    payment_date TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE,
    INDEX idx_payment_status (payment_status),
    INDEX idx_payment_date (payment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Quotes tablosuna eksik alanları ekle (eğer yoksa)
-- Her alan için ayrı ALTER TABLE komutu kullanıyoruz (MySQL uyumluluğu için)

-- Cost list ID alanı
ALTER TABLE quotes ADD COLUMN cost_list_id INT DEFAULT NULL;

-- Container type alanı
ALTER TABLE quotes ADD COLUMN container_type VARCHAR(50) DEFAULT NULL;

-- Custom fields alanı (JSON yerine TEXT kullanıyoruz eski MySQL sürümleri için)
ALTER TABLE quotes ADD COLUMN custom_fields TEXT DEFAULT NULL;

-- Reference images gösterme alanı
ALTER TABLE quotes ADD COLUMN show_reference_images BOOLEAN DEFAULT FALSE;

-- Payment status alanı
ALTER TABLE quotes ADD COLUMN payment_status ENUM('pending', 'partial', 'completed') DEFAULT 'pending';

-- Delivery status alanı
ALTER TABLE quotes ADD COLUMN delivery_status ENUM('pending', 'in_transit', 'delivered') DEFAULT 'pending';

-- Revision count alanı
ALTER TABLE quotes ADD COLUMN revision_count INT DEFAULT 0;

-- Last revision date alanı
ALTER TABLE quotes ADD COLUMN last_revision_date TIMESTAMP NULL;

-- 7. Quotes tablosuna index'ler ekle
ALTER TABLE quotes ADD INDEX idx_cost_list (cost_list_id);
ALTER TABLE quotes ADD INDEX idx_payment_status (payment_status);
ALTER TABLE quotes ADD INDEX idx_delivery_status (delivery_status);

-- 8. Foreign key ekle
ALTER TABLE quotes ADD CONSTRAINT fk_quotes_cost_list FOREIGN KEY (cost_list_id) REFERENCES cost_lists(id) ON DELETE SET NULL;

-- 9. Customers tablosuna telefon alanını güncelle (eğer gerekirse)
ALTER TABLE customers
MODIFY COLUMN phone VARCHAR(25) NOT NULL;

-- 10. Email templates için varsayılan veriler ekle
INSERT IGNORE INTO email_templates (transport_mode_id, language, currency, subject, email_content, quote_content) VALUES
(1, 'tr', 'EUR', 'Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Talep etmiş olduğunuz nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Kargo Türü:</strong> {cargo_type}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>'),

(2, 'tr', 'EUR', 'Havayolu Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Havayolu nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Havayolu Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Ağırlık:</strong> {weight}</p>
<p><strong>Parça Sayısı:</strong> {pieces}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>'),

(3, 'tr', 'EUR', 'Deniz Yolu Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Deniz yolu nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Deniz Yolu Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>'),

(4, 'tr', 'EUR', 'Konteyner Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Konteyner nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Konteyner Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>');

-- Başarı mesajı
SELECT 'Tüm eksik tablolar başarıyla oluşturuldu!' as message;
