-- Veritabanı onarım ve yeniden oluşturma
USE nakliye_teklif;

-- Önce mevcut tabloları temizle (eğer bozuksa)
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS additional_costs;
DROP TABLE IF EXISTS email_logs;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS quotes;
DROP TABLE IF EXISTS cost_lists;
DROP TABLE IF EXISTS email_templates;
DROP TABLE IF EXISTS quote_templates;
DROP TABLE IF EXISTS transport_images;
DROP TABLE IF EXISTS transport_reference_images;
DROP TABLE IF EXISTS transport_modes;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS admin_users;

SET FOREIGN_KEY_CHECKS = 1;

-- Tabloları doğru sırayla yeniden oluştur

-- 1. Admin kullanıcıları tablosu
CREATE TABLE admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role ENUM('admin', 'manager', 'operator') DEFAULT 'operator',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Müşteriler tablosu
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(25) NOT NULL,
    company VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Taşıma modları tablosu
CREATE TABLE transport_modes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(100),
    base_price DECIMAL(10,2) DEFAULT 0.00,
    price_per_kg DECIMAL(10,4) DEFAULT 0.00,
    price_per_km DECIMAL(10,4) DEFAULT 0.00,
    price_per_m3 DECIMAL(10,4) DEFAULT 0.00,
    min_price DECIMAL(10,2) DEFAULT 0.00,
    template TEXT,
    email_template TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Maliyet listeleri tablosu
CREATE TABLE cost_lists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    transport_mode_id INT,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode_id),
    INDEX idx_active (is_active),
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Teklifler tablosu
CREATE TABLE quotes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_number VARCHAR(20) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    transport_mode_id INT NOT NULL,
    origin VARCHAR(255) NOT NULL,
    destination VARCHAR(255) NOT NULL,
    weight DECIMAL(10,2) NOT NULL,
    volume DECIMAL(10,3),
    pieces INT,
    cargo_type ENUM('genel', 'hassas', 'soguk', 'tehlikeli'),
    description TEXT,
    calculated_price DECIMAL(10,2),
    final_price DECIMAL(10,2),
    status ENUM('pending', 'sent', 'accepted', 'rejected', 'expired') DEFAULT 'pending',
    valid_until DATE,
    notes TEXT,
    cost_list_id INT DEFAULT NULL,
    container_type VARCHAR(50) DEFAULT NULL,
    custom_fields TEXT DEFAULT NULL,
    show_reference_images BOOLEAN DEFAULT FALSE,
    payment_status ENUM('pending', 'partial', 'completed') DEFAULT 'pending',
    delivery_status ENUM('pending', 'in_transit', 'delivered') DEFAULT 'pending',
    revision_count INT DEFAULT 0,
    last_revision_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id),
    FOREIGN KEY (cost_list_id) REFERENCES cost_lists(id) ON DELETE SET NULL,
    INDEX idx_quote_number (quote_number),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    INDEX idx_cost_list (cost_list_id),
    INDEX idx_payment_status (payment_status),
    INDEX idx_delivery_status (delivery_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Ek maliyetler tablosu
CREATE TABLE additional_costs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency ENUM('TL', 'USD', 'EUR') DEFAULT 'TL',
    is_additional BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE,
    INDEX idx_additional_costs_quote_id (quote_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Email logları tablosu
CREATE TABLE email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    recipient_email VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    body TEXT,
    status ENUM('sent', 'failed', 'pending') DEFAULT 'pending',
    error_message TEXT,
    sent_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_sent_at (sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Email şablonları tablosu
CREATE TABLE email_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode_id INT NOT NULL,
    language VARCHAR(2) DEFAULT 'tr',
    currency VARCHAR(3) DEFAULT 'EUR',
    subject VARCHAR(255) NOT NULL,
    email_content TEXT NOT NULL,
    quote_content TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Ödeme tablosu
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'TL',
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    transaction_id VARCHAR(255),
    payment_date TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE,
    INDEX idx_payment_status (payment_status),
    INDEX idx_payment_date (payment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Teklif şablonları tablosu
CREATE TABLE quote_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    template_content TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Taşıma görselleri tablosu
CREATE TABLE transport_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode VARCHAR(50) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    image_name VARCHAR(255) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Taşıma referans görselleri tablosu
CREATE TABLE transport_reference_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode VARCHAR(50) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    image_name VARCHAR(255) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Varsayılan verileri ekle

-- Admin kullanıcısı (şifre: admin123)
INSERT INTO admin_users (username, email, password_hash, full_name, role) VALUES
('admin', 'admin@nakliye.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sistem Yöneticisi', 'admin');

-- Taşıma modları
INSERT INTO transport_modes (name, slug, icon, base_price, price_per_kg, price_per_km, min_price) VALUES
('Karayolu', 'karayolu', 'fas fa-truck', 100.00, 2.50, 1.20, 150.00),
('Havayolu', 'havayolu', 'fas fa-plane', 250.00, 8.50, 0.00, 300.00),
('Deniz Yolu', 'denizyolu', 'fas fa-ship', 150.00, 1.80, 0.50, 200.00),
('Konteyner', 'konteyner', 'fas fa-box', 800.00, 0.00, 2.00, 800.00);

-- Email şablonları
INSERT INTO email_templates (transport_mode_id, language, currency, subject, email_content, quote_content) VALUES
(1, 'tr', 'EUR', 'Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p><p>Talep etmiş olduğunuz nakliye hizmeti için teklif hazırlanmıştır.</p>',
'<h3>Teklif Detayları</h3><p><strong>Teklif No:</strong> {quote_number}</p><p><strong>Güzergah:</strong> {origin} → {destination}</p><hr><h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>'),

(2, 'tr', 'EUR', 'Havayolu Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p><p>Havayolu nakliye hizmeti için teklif hazırlanmıştır.</p>',
'<h3>Havayolu Teklif Detayları</h3><p><strong>Teklif No:</strong> {quote_number}</p><p><strong>Güzergah:</strong> {origin} → {destination}</p><hr><h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>'),

(3, 'tr', 'EUR', 'Deniz Yolu Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p><p>Deniz yolu nakliye hizmeti için teklif hazırlanmıştır.</p>',
'<h3>Deniz Yolu Teklif Detayları</h3><p><strong>Teklif No:</strong> {quote_number}</p><p><strong>Güzergah:</strong> {origin} → {destination}</p><hr><h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>'),

(4, 'tr', 'EUR', 'Konteyner Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p><p>Konteyner nakliye hizmeti için teklif hazırlanmıştır.</p>',
'<h3>Konteyner Teklif Detayları</h3><p><strong>Teklif No:</strong> {quote_number}</p><p><strong>Güzergah:</strong> {origin} → {destination}</p><hr><h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>');

SELECT 'Veritabanı başarıyla onarıldı ve yeniden oluşturuldu!' as message;
