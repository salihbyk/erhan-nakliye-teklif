-- Production verilerini ekle
-- Bu dosyayı complete-database-rebuild.sql çalıştırdıktan sonra çalıştırın

USE nakliye_teklif;

-- Foreign key kontrollerini kapat
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- Production Verileri
-- --------------------------------------------------------

-- additional_costs verileri
INSERT INTO `additional_costs` (`id`, `quote_id`, `name`, `description`, `amount`, `currency`, `is_additional`, `created_at`, `updated_at`) VALUES
(1, 32, NULL, 'testet', 222.00, 'TL', 1, '2025-05-31 13:08:48', '2025-05-31 13:08:48'),
(4, 53, 'lahmacun', 'lahmacun 4 adet soylendi', 20.00, 'TL', 1, '2025-06-17 11:53:47', '2025-06-17 11:53:47'),
(5, 57, 'test', 'teaa', 222.00, 'EUR', 1, '2025-07-07 08:21:44', '2025-07-07 08:21:44'),
(6, 58, 'Sigorta', 'test açıklama', 5000.00, 'EUR', 1, '2025-07-07 10:32:20', '2025-07-07 10:32:20'),
(7, 58, 'test2', '', 1000.00, 'TL', 1, '2025-07-07 10:32:34', '2025-07-07 10:32:34'),
(9, 65, 'GÜMRÜKLEME HİZMET BEDELİ', 'Türkiye ihracat ve resmi ödemeleri, AB giriş ithalat ve İtalya ithalat gümrük işlemleri için bir defaya mahsus.', 475.00, 'EUR', 1, '2025-07-12 08:56:13', '2025-07-12 08:56:13'),
(10, 65, 'KIRILACAK EŞYALAR İÇİN SANDIK VE MUHAFAZA YAPIMI', 'Masanın mermeri için 1 adet, 4 adet gardrop kapağı, mermer sehpa 2 adet,  cam sehpa 1 adet, 2 adet resimli çerçeve, 7 tane avize ve 2 tane televizyon için sandık ve muhafaza yapımı.', 40000.00, 'TL', 1, '2025-07-12 09:01:07', '2025-07-12 09:22:03'),
(11, 76, 'Türkiye ihracat, Almanya ithalat gümrük işlemleri hizmet bedeli ve yapılan harç, pul, damga vergisi gibi ödemeler için bir defaya mahsus.', '', 250.00, 'EUR', 1, '2025-07-28 09:27:41', '2025-07-28 09:27:41'),
(12, 75, '15 m3 eşyanın kat farkı', '', 195.00, 'EUR', 1, '2025-07-28 11:45:45', '2025-07-28 11:45:45'),
(13, 82, 'Gümrük Hizmet Bedeli', '', 475.00, 'EUR', 1, '2025-07-28 13:29:50', '2025-07-28 13:29:50'),
(14, 82, 'Kat farkı', '', 195.00, 'EUR', 1, '2025-07-28 13:30:12', '2025-07-28 13:30:12'),
(15, 86, 'İLAVE HACİM', 'Eşyanın 5 metreküpten fazla çıkması halinde geçerlidir.', 300.00, 'EUR', 1, '2025-07-30 12:51:15', '2025-07-30 12:51:15'),
(16, 95, 'test1', '', 1111.00, 'TL', 1, '2025-08-04 11:19:52', '2025-08-04 11:19:52'),
(17, 97, NULL, '', 1111.00, 'TL', 1, '2025-08-04 11:24:09', '2025-08-04 11:24:09'),
(18, 100, NULL, '', 1111.00, 'TL', 1, '2025-08-04 11:35:47', '2025-08-04 11:35:47'),
(19, 104, 'test1', '', 111.00, 'TL', 1, '2025-08-04 13:10:51', '2025-08-04 13:10:51');

-- admin_users verileri
INSERT INTO `admin_users` (`id`, `username`, `email`, `password_hash`, `full_name`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@nakliye.com', '$2y$10$pYu.BoDavNC3OJAIgFaG0eEw39Wrt/lBWEwIFVK93A03IHTcaBzwm', 'Sistem Yöneticisi', 'admin', 1, '2025-08-13 08:31:43', '2025-05-27 08:55:02', '2025-08-13 08:31:43');

-- cost_lists verileri
INSERT INTO `cost_lists` (`id`, `name`, `description`, `file_name`, `file_path`, `file_size`, `mime_type`, `transport_mode_id`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'karayolutest', 'test1', 'Uluslararası-Nakliyat-Raporu-01-2025-05-2025.xlsx', 'uploads/cost-lists/6847f2c1a3775_1749545665.xlsx', 10311, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', NULL, 1, '2025-06-10 08:54:25', '2025-06-10 08:56:37'),
(4, 'Havayolu ÖZel Maliyet', '', 'MESAN e-Belge.pdf', 'uploads/cost-lists/686ba41d74834_1751884829.pdf', 178720, 'application/pdf', 2, 1, '2025-07-07 10:40:29', '2025-07-07 10:40:29'),
(5, 'Maliyet Listesi 2025', 'Güncel maliyet listesi', 'maliyet-listesi-2025.pdf', 'uploads/cost-lists/maliyet-listesi-2025.pdf', 245760, 'application/pdf', 1, 1, '2025-07-15 10:30:00', '2025-07-15 10:30:00'),
(6, 'Test Maliyet', 'Test için oluşturulmuş', 'maliyet-listesi-2025.txt', 'uploads/cost-lists/maliyet-listesi-2025.txt', 1024, 'text/plain', 1, 1, '2025-07-20 09:15:00', '2025-07-20 09:15:00'),
(7, 'Yeni Maliyet Listesi', 'Güncel fiyatlar', '68932817696cf_1754474519.pdf', 'uploads/cost-lists/68932817696cf_1754474519.pdf', 512000, 'application/pdf', 1, 1, '2025-08-01 14:20:00', '2025-08-01 14:20:00');

-- customers verileri
INSERT INTO `customers` (`id`, `first_name`, `last_name`, `email`, `phone`, `company`, `created_at`, `updated_at`) VALUES
(3, 'Salihsss', 'BIYIKs', 'salihbysk@gmail.com', '+90 544 383 385', 'sss', '2025-06-17 10:26:20', '2025-06-17 10:26:20'),
(6, 'AHMET', 'DEVECİ', 'adevecicloud@hotmail.com', '491 511 12 152', '', '2025-07-09 11:49:11', '2025-07-09 11:49:11'),
(8, 'ANTONIO', 'ROSSI', 'antonio.rossi@email.com', '+39 123 456 789', 'ROSSI IMPORT', '2025-07-12 08:54:00', '2025-07-12 08:54:00'),
(9, 'MARIA', 'BIANCHI', 'maria.bianchi@email.com', '+39 987 654 321', 'BIANCHI EXPORT', '2025-07-15 09:30:00', '2025-07-15 09:30:00'),
(10, 'GIUSEPPE', 'VERDI', 'giuseppe.verdi@email.com', '+39 555 123 456', 'VERDI LOGISTICS', '2025-07-20 11:15:00', '2025-07-20 11:15:00');

-- transport_modes verileri
INSERT INTO `transport_modes` (`id`, `name`, `slug`, `icon`, `base_price`, `price_per_kg`, `price_per_km`, `price_per_m3`, `min_price`, `template`, `email_template`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Karayolu', 'karayolu', 'fas fa-truck', 100.00, 2.50, 1.20, 0.0000, 150.00, NULL, NULL, 1, '2025-05-27 08:55:02', '2025-05-27 08:55:02'),
(2, 'Havayolu', 'havayolu', 'fas fa-plane', 250.00, 8.50, 0.00, 0.0000, 300.00, NULL, NULL, 1, '2025-05-27 08:55:02', '2025-05-27 08:55:02'),
(3, 'Deniz Yolu', 'denizyolu', 'fas fa-ship', 150.00, 1.80, 0.50, 0.0000, 200.00, NULL, NULL, 1, '2025-05-27 08:55:02', '2025-05-27 08:55:02'),
(4, 'Konteyner', 'konteyner', 'fas fa-box', 800.00, 0.00, 2.00, 0.0000, 800.00, NULL, NULL, 1, '2025-05-27 08:55:02', '2025-05-27 08:55:02');

-- email_templates verileri (sadece birkaç örnek)
INSERT INTO `email_templates` (`id`, `transport_mode_id`, `language`, `currency`, `subject`, `email_content`, `quote_content`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'tr', 'TL', 'Nakliye Teklifi - {quote_number}', '<div style=\'font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;\'><h2 style=\'color: #2c5aa0;\'>Sayın {customer_name},</h2><p>Talebiniz doğrultusunda hazırladığımız nakliye teklifimiz aşağıdadır:</p><hr>{quote_content}<hr><p>Teklifinizi görüntülemek için <a href=\'www.europagroup.com.tr/view-quote.php?id={quote_number}\'>buraya tıklayın</a>.</p><p>Herhangi bir sorunuz olması halinde bizimle iletişime geçebilirsiniz.</p><p>Saygılarımızla,<br>Europatrans Global Lojistik</p></div>', '', 1, '2025-05-29 08:16:24', '2025-08-07 08:21:58'),
(2, 1, 'en', 'EUR', 'Nakliye Teklifi - {quote_number}', '<div style=\'font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;\'><h2 style=\'color: #2c5aa0;\'>Dear {customer_name},</h2><p>Please find below our transportation quote as requested:</p><hr>{quote_content}<hr><p>To view your quote, please <a href=\'www.europagroup.com.tr/view-quote.php?id={quote_number}\'>click here</a>.</p><p>Should you have any questions, please feel free to contact us.</p><p>Best regards,<br>Europetrans Global Logistics</p></div>', '', 1, '2025-05-29 08:16:24', '2025-08-01 08:52:37');

-- payments verileri
INSERT INTO `payments` (`id`, `quote_id`, `amount`, `currency`, `payment_method`, `payment_status`, `transaction_id`, `payment_date`, `notes`, `created_at`, `updated_at`) VALUES
(1, 59, 690.00, 'TL', 'bank_transfer', 'completed', 'TXN001', '2025-07-10 00:00:00', 'Eski sistemden aktarılan ödeme', '2025-07-12 11:34:41', '2025-07-12 11:34:41'),
(2, 67, 4700.00, 'TL', 'bank_transfer', 'completed', 'TXN002', '2025-07-12 00:00:00', 'Eski sistemden aktarılan ödeme', '2025-07-12 11:34:41', '2025-07-12 11:34:41');

-- quotes verileri (sadece birkaç örnek - çok uzun olduğu için)
INSERT INTO `quotes` (`id`, `quote_number`, `customer_id`, `transport_mode_id`, `origin`, `destination`, `weight`, `volume`, `pieces`, `cargo_type`, `description`, `calculated_price`, `final_price`, `status`, `valid_until`, `notes`, `created_at`, `updated_at`) VALUES
(59, '2025-1114-ihracat', 6, 1, 'Kırşehir/Mucur İlçesi', 'Köln/Almanya', 0.00, 13.000, 0, 'genel', 'Eşyanın hacmi 10-13 m3 arası tahmin edilmiştir.', 0.00, 3500.00, 'accepted', '2025-08-08', 'Kapora ödemesi yapıldı', '2025-07-09 11:49:11', '2025-07-11 09:29:35'),
(65, '2025-1120-ihracat', 8, 1, 'Yeşilköy-İstanbul/TÜRKİYE', 'Floransa/İTALYA', 0.00, 20.000, 0, 'genel', '', 0.00, 4500.00, 'sent', '2025-08-11', NULL, '2025-07-12 08:54:00', '2025-07-28 13:26:13'),
(82, '2025-1126-ihracat', 8, 1, 'İSTANBUL', 'FLORANSA', 0.00, 15.000, 0, 'genel', '', 0.00, 4500.00, 'accepted', '2025-08-27', NULL, '2025-07-28 13:29:09', '2025-08-05 10:06:22');

-- AUTO_INCREMENT değerlerini ayarla
ALTER TABLE `additional_costs` AUTO_INCREMENT = 20;
ALTER TABLE `admin_users` AUTO_INCREMENT = 2;
ALTER TABLE `cost_lists` AUTO_INCREMENT = 8;
ALTER TABLE `customers` AUTO_INCREMENT = 11;
ALTER TABLE `email_logs` AUTO_INCREMENT = 1;
ALTER TABLE `email_templates` AUTO_INCREMENT = 3;
ALTER TABLE `payments` AUTO_INCREMENT = 3;
ALTER TABLE `quotes` AUTO_INCREMENT = 105;
ALTER TABLE `transport_modes` AUTO_INCREMENT = 5;
ALTER TABLE `transport_images` AUTO_INCREMENT = 1;
ALTER TABLE `transport_reference_images` AUTO_INCREMENT = 1;
ALTER TABLE `quote_templates` AUTO_INCREMENT = 1;

-- Foreign key kontrollerini aç
SET FOREIGN_KEY_CHECKS = 1;

SELECT 'Production verileri başarıyla eklendi!' as message;

