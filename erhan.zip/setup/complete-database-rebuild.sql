-- Veritabanını tamamen yeniden oluştur
-- Bu dosyayı phpMyAdmin'de çalıştırın

-- Mevcut veritabanını sil
DROP DATABASE IF EXISTS nakliye_teklif;

-- Yeni veritabanını oluştur
CREATE DATABASE nakliye_teklif CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Veritabanını seç
USE nakliye_teklif;

-- SQL ayarları
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- Karakter seti ayarları
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- Foreign key kontrollerini kapat
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- Tablo yapıları (production'dan alınmış)
-- --------------------------------------------------------

-- additional_costs tablosu
CREATE TABLE `additional_costs` (
  `id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` enum('TL','USD','EUR') DEFAULT 'TL',
  `is_additional` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- admin_users tablosu
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('admin','manager','operator') DEFAULT 'operator',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- cost_lists tablosu
CREATE TABLE `cost_lists` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `transport_mode_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- customers tablosu
CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- email_logs tablosu
CREATE TABLE `email_logs` (
  `id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL,
  `recipient_email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `status` enum('sent','failed','pending') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- email_templates tablosu
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL,
  `transport_mode_id` int(11) NOT NULL,
  `language` varchar(2) DEFAULT 'tr',
  `currency` varchar(3) DEFAULT 'EUR',
  `subject` varchar(255) NOT NULL,
  `email_content` text NOT NULL,
  `quote_content` text NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- payments tablosu
CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'TL',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('pending','completed','failed','cancelled') DEFAULT 'pending',
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_date` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- quotes tablosu
CREATE TABLE `quotes` (
  `id` int(11) NOT NULL,
  `quote_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `transport_mode_id` int(11) NOT NULL,
  `origin` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `weight` decimal(10,2) NOT NULL,
  `volume` decimal(10,3) DEFAULT NULL,
  `pieces` int(11) DEFAULT NULL,
  `cargo_type` enum('genel','hassas','soguk','tehlikeli') DEFAULT NULL,
  `description` text DEFAULT NULL,
  `calculated_price` decimal(10,2) DEFAULT NULL,
  `final_price` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','sent','accepted','rejected','expired') DEFAULT 'pending',
  `valid_until` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `cost_list_id` int(11) DEFAULT NULL,
  `container_type` varchar(50) DEFAULT NULL,
  `custom_fields` text DEFAULT NULL,
  `show_reference_images` tinyint(1) DEFAULT 0,
  `payment_status` enum('pending','partial','completed') DEFAULT 'pending',
  `delivery_status` enum('pending','in_transit','delivered') DEFAULT 'pending',
  `revision_count` int(11) DEFAULT 0,
  `last_revision_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- transport_modes tablosu
CREATE TABLE `transport_modes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `base_price` decimal(10,2) DEFAULT 0.00,
  `price_per_kg` decimal(10,4) DEFAULT 0.00,
  `price_per_km` decimal(10,4) DEFAULT 0.00,
  `price_per_m3` decimal(10,4) DEFAULT 0.00,
  `min_price` decimal(10,2) DEFAULT 0.00,
  `template` text DEFAULT NULL,
  `email_template` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- transport_images tablosu
CREATE TABLE `transport_images` (
  `id` int(11) NOT NULL,
  `transport_mode` varchar(50) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- transport_reference_images tablosu
CREATE TABLE `transport_reference_images` (
  `id` int(11) NOT NULL,
  `transport_mode` varchar(50) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- quote_templates tablosu
CREATE TABLE `quote_templates` (
  `id` int(11) NOT NULL,
  `transport_mode_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `template_content` text NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Primary Key'ler ve Index'ler
-- --------------------------------------------------------

-- additional_costs
ALTER TABLE `additional_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_additional_costs_quote_id` (`quote_id`);

-- admin_users
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

-- cost_lists
ALTER TABLE `cost_lists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transport_mode` (`transport_mode_id`),
  ADD KEY `idx_active` (`is_active`);

-- customers
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_phone` (`phone`);

-- email_logs
ALTER TABLE `email_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_sent_at` (`sent_at`);

-- email_templates
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

-- payments
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payment_status` (`payment_status`),
  ADD KEY `idx_payment_date` (`payment_date`);

-- quotes
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `quote_number` (`quote_number`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_cost_list` (`cost_list_id`),
  ADD KEY `idx_payment_status` (`payment_status`),
  ADD KEY `idx_delivery_status` (`delivery_status`);

-- transport_modes
ALTER TABLE `transport_modes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

-- transport_images
ALTER TABLE `transport_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transport_mode` (`transport_mode`),
  ADD KEY `idx_active` (`is_active`);

-- transport_reference_images
ALTER TABLE `transport_reference_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transport_mode` (`transport_mode`),
  ADD KEY `idx_active` (`is_active`);

-- quote_templates
ALTER TABLE `quote_templates`
  ADD PRIMARY KEY (`id`);

-- --------------------------------------------------------
-- AUTO_INCREMENT ayarları
-- --------------------------------------------------------

ALTER TABLE `additional_costs` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `admin_users` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `cost_lists` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `customers` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `email_logs` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `email_templates` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `payments` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `quotes` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `transport_modes` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `transport_images` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `transport_reference_images` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `quote_templates` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

-- --------------------------------------------------------
-- Foreign Key'ler
-- --------------------------------------------------------

ALTER TABLE `additional_costs`
  ADD CONSTRAINT `fk_additional_costs_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE;

ALTER TABLE `cost_lists`
  ADD CONSTRAINT `fk_cost_lists_transport_mode` FOREIGN KEY (`transport_mode_id`) REFERENCES `transport_modes` (`id`) ON DELETE SET NULL;

ALTER TABLE `email_logs`
  ADD CONSTRAINT `fk_email_logs_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE;

ALTER TABLE `email_templates`
  ADD CONSTRAINT `fk_email_templates_transport_mode` FOREIGN KEY (`transport_mode_id`) REFERENCES `transport_modes` (`id`);

ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payments_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE;

ALTER TABLE `quotes`
  ADD CONSTRAINT `fk_quotes_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_quotes_transport_mode` FOREIGN KEY (`transport_mode_id`) REFERENCES `transport_modes` (`id`),
  ADD CONSTRAINT `fk_quotes_cost_list` FOREIGN KEY (`cost_list_id`) REFERENCES `cost_lists` (`id`) ON DELETE SET NULL;

ALTER TABLE `quote_templates`
  ADD CONSTRAINT `fk_quote_templates_transport_mode` FOREIGN KEY (`transport_mode_id`) REFERENCES `transport_modes` (`id`) ON DELETE CASCADE;

-- Foreign key kontrollerini aç
SET FOREIGN_KEY_CHECKS = 1;

-- İşlemi tamamla
COMMIT;

-- Karakter seti ayarlarını geri yükle
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

SELECT 'Veritabanı yapısı başarıyla oluşturuldu! Şimdi step2 dosyasını çalıştırarak verileri ekleyin.' as message;

