-- Production veritabanını local ortama aktarma
-- Bu dosyayı phpMyAdmin'de çalıştırın

-- Önce mevcut veritabanını temizle
DROP DATABASE IF EXISTS nakliye_teklif;

-- Yeni veritabanını oluştur
CREATE DATABASE nakliye_teklif CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Veritabanını seç
USE nakliye_teklif;

-- UYARI: Bu noktada europagr_teklif.sql dosyasının içeriğini buraya kopyalamanız gerekiyor
-- Aşağıdaki adımları takip edin:

-- 1. europagr_teklif.sql dosyasını açın
-- 2. Tüm içeriği kopyalayın (Ctrl+A, Ctrl+C)
-- 3. Bu satırın altına yapıştırın
-- 4. Bu dosyayı phpMyAdmin'de çalıştırın

-- europagr_teklif.sql içeriği buraya gelecek --

SELECT 'Production veritabanı başarıyla import edildi!' as message;

