<?php
// Veritabanı bağlantısını test etmek için basit script

require_once '../config/database.php';

try {
    $database = new Database();
    $pdo = $database->getConnection();

    if ($pdo) {
        echo "<h2>✅ Veritabanı Bağlantısı Başarılı!</h2>";

        // Mevcut tabloları listele
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

        echo "<h3>Mevcut Tablolar:</h3>";
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li>$table</li>";
        }
        echo "</ul>";

        // Eksik tabloları kontrol et
        $required_tables = [
            'customers',
            'transport_modes',
            'quotes',
            'admin_users',
            'email_logs',
            'additional_costs',
            'cost_lists',
            'email_templates',
            'transport_images',
            'payments'
        ];

        $missing_tables = array_diff($required_tables, $tables);

        if (empty($missing_tables)) {
            echo "<h3 style='color: green;'>✅ Tüm gerekli tablolar mevcut!</h3>";
        } else {
            echo "<h3 style='color: red;'>❌ Eksik Tablolar:</h3>";
            echo "<ul>";
            foreach ($missing_tables as $table) {
                echo "<li style='color: red;'>$table</li>";
            }
            echo "</ul>";
            echo "<p><strong>Çözüm:</strong> <code>setup/fix-missing-tables.sql</code> dosyasını phpMyAdmin'de çalıştırın.</p>";
        }

    } else {
        echo "<h2 style='color: red;'>❌ Veritabanı Bağlantısı Başarısız!</h2>";
    }

} catch (Exception $e) {
    echo "<h2 style='color: red;'>❌ Hata: " . $e->getMessage() . "</h2>";
}
?>
