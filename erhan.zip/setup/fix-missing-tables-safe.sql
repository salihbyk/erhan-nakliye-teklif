-- Eksik tabloları güvenli şekilde oluşturmak için SQL dosyası
-- Bu dosya mevcut yapıları bozmadan eksik tabloları ekler

USE nakliye_teklif;

-- 1. Additional costs tablosu
CREATE TABLE IF NOT EXISTS additional_costs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency ENUM('TL', 'USD', 'EUR') DEFAULT 'TL',
    is_additional BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_additional_costs_quote_id (quote_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Cost lists tablosu
CREATE TABLE IF NOT EXISTS cost_lists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    transport_mode_id INT,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode_id),
    INDEX idx_active (is_active),
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Email templates tablosu
CREATE TABLE IF NOT EXISTS email_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode_id INT NOT NULL,
    language VARCHAR(2) DEFAULT 'tr',
    currency VARCHAR(3) DEFAULT 'EUR',
    subject VARCHAR(255) NOT NULL,
    email_content TEXT NOT NULL,
    quote_content TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Transport images tablosu
CREATE TABLE IF NOT EXISTS transport_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode VARCHAR(50) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    image_name VARCHAR(255) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Payments tablosu
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'TL',
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    transaction_id VARCHAR(255),
    payment_date TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE,
    INDEX idx_payment_status (payment_status),
    INDEX idx_payment_date (payment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Quotes tablosuna eksik alanları güvenli şekilde ekle
-- Önce alanların var olup olmadığını kontrol ederiz

-- Geçici prosedür oluştur
DELIMITER $$

CREATE PROCEDURE AddColumnIfNotExists(
    IN table_name VARCHAR(100),
    IN column_name VARCHAR(100),
    IN column_definition TEXT
)
BEGIN
    DECLARE column_exists INT DEFAULT 0;

    SELECT COUNT(*) INTO column_exists
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = table_name
    AND COLUMN_NAME = column_name;

    IF column_exists = 0 THEN
        SET @sql = CONCAT('ALTER TABLE ', table_name, ' ADD COLUMN ', column_name, ' ', column_definition);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;

-- Alanları ekle
CALL AddColumnIfNotExists('quotes', 'cost_list_id', 'INT DEFAULT NULL');
CALL AddColumnIfNotExists('quotes', 'container_type', 'VARCHAR(50) DEFAULT NULL');
CALL AddColumnIfNotExists('quotes', 'custom_fields', 'TEXT DEFAULT NULL');
CALL AddColumnIfNotExists('quotes', 'show_reference_images', 'BOOLEAN DEFAULT FALSE');
CALL AddColumnIfNotExists('quotes', 'payment_status', 'ENUM(\'pending\', \'partial\', \'completed\') DEFAULT \'pending\'');
CALL AddColumnIfNotExists('quotes', 'delivery_status', 'ENUM(\'pending\', \'in_transit\', \'delivered\') DEFAULT \'pending\'');
CALL AddColumnIfNotExists('quotes', 'revision_count', 'INT DEFAULT 0');
CALL AddColumnIfNotExists('quotes', 'last_revision_date', 'TIMESTAMP NULL');

-- Prosedürü sil
DROP PROCEDURE AddColumnIfNotExists;

-- 7. Index'leri güvenli şekilde ekle
-- Index varsa hata vermez, yoksa ekler

-- Cost list index
SET @sql = 'CREATE INDEX idx_cost_list ON quotes(cost_list_id)';
SET @sql_check = (SELECT COUNT(*) FROM information_schema.statistics
                  WHERE table_schema = DATABASE()
                  AND table_name = 'quotes'
                  AND index_name = 'idx_cost_list');

SET @sql = IF(@sql_check > 0, 'SELECT "Index idx_cost_list already exists" as message', @sql);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Payment status index
SET @sql = 'CREATE INDEX idx_payment_status ON quotes(payment_status)';
SET @sql_check = (SELECT COUNT(*) FROM information_schema.statistics
                  WHERE table_schema = DATABASE()
                  AND table_name = 'quotes'
                  AND index_name = 'idx_payment_status');

SET @sql = IF(@sql_check > 0, 'SELECT "Index idx_payment_status already exists" as message', @sql);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Delivery status index
SET @sql = 'CREATE INDEX idx_delivery_status ON quotes(delivery_status)';
SET @sql_check = (SELECT COUNT(*) FROM information_schema.statistics
                  WHERE table_schema = DATABASE()
                  AND table_name = 'quotes'
                  AND index_name = 'idx_delivery_status');

SET @sql = IF(@sql_check > 0, 'SELECT "Index idx_delivery_status already exists" as message', @sql);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 8. Email templates için varsayılan veriler ekle (sadece yoksa)
INSERT IGNORE INTO email_templates (transport_mode_id, language, currency, subject, email_content, quote_content) VALUES
(1, 'tr', 'EUR', 'Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Talep etmiş olduğunuz nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Kargo Türü:</strong> {cargo_type}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>'),

(2, 'tr', 'EUR', 'Havayolu Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Havayolu nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Havayolu Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Ağırlık:</strong> {weight}</p>
<p><strong>Parça Sayısı:</strong> {pieces}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>'),

(3, 'tr', 'EUR', 'Deniz Yolu Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Deniz yolu nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Deniz Yolu Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>'),

(4, 'tr', 'EUR', 'Konteyner Nakliye Teklifi - {quote_number}',
'<p>Sayın {customer_name},</p>
<p>Konteyner nakliye hizmeti için teklif hazırlanmıştır.</p>
<p>Teklif detaylarını aşağıda bulabilirsiniz:</p>',
'<h3>Konteyner Teklif Detayları</h3>
<p><strong>Teklif No:</strong> {quote_number}</p>
<p><strong>Güzergah:</strong> {origin} → {destination}</p>
<p><strong>Hacim:</strong> {volume}</p>
<p><strong>Geçerlilik Tarihi:</strong> {valid_until}</p>
<hr>
<h3 style="color: #2c5aa0;">Toplam Fiyat: {price}</h3>
<p><em>Bu fiyat KDV dahildir.</em></p>');

-- Başarı mesajı
SELECT 'Tüm eksik tablolar ve alanlar güvenli şekilde oluşturuldu!' as message;
