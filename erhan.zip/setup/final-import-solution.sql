-- Final import çözümü
-- Bu dosyayı phpMyAdmin'de çalıştırın

-- Mevcut veritabanını temizle
USE nakliye_teklif;

-- Eğer tablolar varsa sil
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS additional_costs;
DROP TABLE IF EXISTS admin_users;
DROP TABLE IF EXISTS cost_lists;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS email_logs;
DROP TABLE IF EXISTS email_templates;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS quotes;
DROP TABLE IF EXISTS quote_templates;
DROP TABLE IF EXISTS transport_images;
DROP TABLE IF EXISTS transport_modes;
DROP TABLE IF EXISTS transport_reference_images;
SET FOREIGN_KEY_CHECKS = 1;

-- Şimdi europagr_teklif.sql dosyasının içeriğini buraya kopyalayın
-- SADECE CREATE TABLE ve INSERT komutlarını kopyalayın
-- Veritabanı oluşturma komutlarını (CREATE DATABASE) kopyalamayın

-- europagr_teklif.sql içeriği buraya gelecek (satır 30'dan başlayarak)

SELECT 'Hazır! europagr_teklif.sql içeriğini buraya kopyalayıp çalıştırın.' as message;

