-- Temiz production veritabanı import dosyası
-- Bu dosyayı phpMyAdmin'de çalıştırın

USE nakliye_teklif;

-- Foreign key kontrollerini kapat
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Mevcut tabloları sil
DROP TABLE IF EXISTS additional_costs;
DROP TABLE IF EXISTS admin_users;
DROP TABLE IF EXISTS cost_lists;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS email_logs;
DROP TABLE IF EXISTS email_templates;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS quotes;
DROP TABLE IF EXISTS quote_templates;
DROP TABLE IF EXISTS transport_images;
DROP TABLE IF EXISTS transport_modes;
DROP TABLE IF EXISTS transport_reference_images;

-- --------------------------------------------------------
-- ADIM 1: Bu dosyayı önce çalıştırın
-- --------------------------------------------------------

-- Foreign key kontrollerini aç
SET FOREIGN_KEY_CHECKS = 1;

SELECT 'Tablolar temizlendi. Şimdi ADIM 2\'yi uygulayın.' as message;

