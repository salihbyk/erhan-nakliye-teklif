-- Mevcut tabloları temizleyip production veritabanını import etme
-- Bu dosyayı phpMyAdmin'de çalıştırın

USE nakliye_teklif;

-- Foreign key kontrollerini kapat
SET FOREIGN_KEY_CHECKS = 0;

-- Mevcut tabloları sil (eğer varsa)
DROP TABLE IF EXISTS additional_costs;
DROP TABLE IF EXISTS admin_users;
DROP TABLE IF EXISTS cost_lists;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS email_logs;
DROP TABLE IF EXISTS email_templates;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS quotes;
DROP TABLE IF EXISTS quote_templates;
DROP TABLE IF EXISTS transport_images;
DROP TABLE IF EXISTS transport_modes;
DROP TABLE IF EXISTS transport_reference_images;

-- Foreign key kontrollerini aç
SET FOREIGN_KEY_CHECKS = 1;

-- Şimdi europagr_teklif.sql dosyasının içeriğini buraya kopyalayın
-- (Sadece CREATE TABLE ve INSERT komutlarını, veritabanı oluşturma komutlarını değil)

SELECT 'Tablolar temizlendi. Şimdi europagr_teklif.sql içeriğini ekleyebilirsiniz.' as message;

