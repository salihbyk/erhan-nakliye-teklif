-- Kalan eksik tabloları oluştur
USE nakliye_teklif;

-- Transport modes tablosu (eksik olan)
CREATE TABLE IF NOT EXISTS transport_modes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(100),
    base_price DECIMAL(10,2) DEFAULT 0.00,
    price_per_kg DECIMAL(10,4) DEFAULT 0.00,
    price_per_km DECIMAL(10,4) DEFAULT 0.00,
    price_per_m3 DECIMAL(10,4) DEFAULT 0.00,
    min_price DECIMAL(10,2) DEFAULT 0.00,
    template TEXT,
    email_template TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transport images tablosu (eksik olan)
CREATE TABLE IF NOT EXISTS transport_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode VARCHAR(50) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    image_name VARCHAR(255) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Quote templates tablosu (eğer eksikse)
CREATE TABLE IF NOT EXISTS quote_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    template_content TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transport reference images tablosu (eğer eksikse)
CREATE TABLE IF NOT EXISTS transport_reference_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transport_mode VARCHAR(50) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    image_name VARCHAR(255) NOT NULL,
    file_size INT,
    mime_type VARCHAR(100),
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_transport_mode (transport_mode),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Varsayılan taşıma modlarını ekle
INSERT IGNORE INTO transport_modes (name, slug, icon, base_price, price_per_kg, price_per_km, min_price) VALUES
('Karayolu', 'karayolu', 'fas fa-truck', 100.00, 2.50, 1.20, 150.00),
('Havayolu', 'havayolu', 'fas fa-plane', 250.00, 8.50, 0.00, 300.00),
('Deniz Yolu', 'denizyolu', 'fas fa-ship', 150.00, 1.80, 0.50, 200.00),
('Konteyner', 'konteyner', 'fas fa-box', 800.00, 0.00, 2.00, 800.00);

-- Quotes tablosuna eksik alanları ekle
ALTER TABLE quotes ADD COLUMN cost_list_id INT DEFAULT NULL;
ALTER TABLE quotes ADD COLUMN container_type VARCHAR(50) DEFAULT NULL;
ALTER TABLE quotes ADD COLUMN custom_fields TEXT DEFAULT NULL;
ALTER TABLE quotes ADD COLUMN show_reference_images BOOLEAN DEFAULT FALSE;
ALTER TABLE quotes ADD COLUMN payment_status ENUM('pending', 'partial', 'completed') DEFAULT 'pending';
ALTER TABLE quotes ADD COLUMN delivery_status ENUM('pending', 'in_transit', 'delivered') DEFAULT 'pending';
ALTER TABLE quotes ADD COLUMN revision_count INT DEFAULT 0;
ALTER TABLE quotes ADD COLUMN last_revision_date TIMESTAMP NULL;

-- Index'leri ekle
ALTER TABLE quotes ADD INDEX idx_cost_list (cost_list_id);
ALTER TABLE quotes ADD INDEX idx_payment_status (payment_status);
ALTER TABLE quotes ADD INDEX idx_delivery_status (delivery_status);

-- Foreign key'leri ekle
ALTER TABLE quotes ADD CONSTRAINT fk_quotes_transport_mode FOREIGN KEY (transport_mode_id) REFERENCES transport_modes(id);
ALTER TABLE quotes ADD CONSTRAINT fk_quotes_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE;
ALTER TABLE quotes ADD CONSTRAINT fk_quotes_cost_list FOREIGN KEY (cost_list_id) REFERENCES cost_lists(id) ON DELETE SET NULL;

SELECT 'Tüm eksik tablolar ve alanlar başarıyla eklendi!' as message;
