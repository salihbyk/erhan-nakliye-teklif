<?php
/**
 * Demo güncelleme bildirimi testi
 */

require_once '../config/database.php';
require_once '../includes/update-functions.php';

try {
    // Demo güncelleme simülasyonu
    $newVersion = '1.2.0';
    $description = 'Admin giriş butonu eklendi - yeni güncelleme mevcut!';

    echo "<h2>Demo Güncelleme Bildirimi Testi</h2>";

    // Sistem ayarlarını güncelle - demo güncelleme mevcut
    updateSystemSetting('cached_update_info', json_encode([
        'update_available' => true,
        'latest_version' => $newVersion,
        'current_version' => getCurrentSystemVersion(),
        'update_info' => [
            'description' => $description,
            'changelog' => [
                'modified' => ['index.php'],
                'description' => $description
            ]
        ],
        'download_url' => 'http://localhost:8000/tools/update-server.php'
    ]));

    // Bildirim durumunu sıfırla
    updateSystemSetting('update_notification_shown', 0);
    updateSystemSetting('last_update_check', time());

    echo "<div style='color: green; padding: 20px; border: 2px solid green; border-radius: 10px;'>";
    echo "✅ Demo güncelleme bildirimi aktif edildi!<br>";
    echo "📍 Güncelleme: v$newVersion<br>";
    echo "📝 Açıklama: $description<br>";
    echo "<br>";
    echo "🎯 <strong>Admin paneline gidin:</strong><br>";
    echo "➡️ <a href='index.php' style='color: blue; font-weight: bold;'>Admin Dashboard</a><br>";
    echo "<br>";
    echo "Artık admin panelinde WordPress benzeri güncelleme bildirimi göreceksiniz!";
    echo "</div>";

    echo "<br><br>";
    echo "<h3>Sistem Durumu</h3>";
    echo "Mevcut versiyon: " . getCurrentSystemVersion() . "<br>";
    echo "Demo yeni versiyon: " . $newVersion . "<br>";
    echo "Bildirim durumu: Aktif<br>";

} catch (Exception $e) {
    echo "<div style='color: red;'>Hata: " . $e->getMessage() . "</div>";
}
?>

<style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    h2, h3 { color: #333; }
</style>
