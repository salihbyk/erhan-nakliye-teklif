<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Oturum kontrolü
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

try {
    // Veritabanı bağlantısı
    $database = new Database();
    $db = $database->getConnection();

    // İstatistikleri al
    $stats = [];

    // Toplam teklif sayısı
    $stmt = $db->query("SELECT COUNT(*) as total FROM quotes");
    $stats['total_quotes'] = $stmt->fetch()['total'];

    // Bu ayki teklifler
    $stmt = $db->query("SELECT COUNT(*) as total FROM quotes WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())");
    $stats['monthly_quotes'] = $stmt->fetch()['total'];

    // Toplam müşteri sayısı
    $stmt = $db->query("SELECT COUNT(*) as total FROM customers");
    $stats['total_customers'] = $stmt->fetch()['total'];

    // Toplam gelir (kabul edilen teklifler)
    $stmt = $db->query("SELECT SUM(final_price) as total FROM quotes WHERE status = 'accepted'");
    $result = $stmt->fetch();
    $stats['total_revenue'] = $result['total'] ?? 0;

    // Son teklifler
    $stmt = $db->prepare("
        SELECT q.quote_number, q.created_at, q.final_price, q.status,
               c.first_name, c.last_name, tm.name as transport_mode
        FROM quotes q
        JOIN customers c ON q.customer_id = c.id
        JOIN transport_modes tm ON q.transport_mode_id = tm.id
        ORDER BY q.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_quotes = $stmt->fetchAll();

    // Aylık grafik verileri (son 6 ay)
    $monthly_data = [];
    for ($i = 5; $i >= 0; $i--) {
        $month = date('Y-m', strtotime("-$i months"));
        $stmt = $db->prepare("
            SELECT COUNT(*) as count, SUM(final_price) as revenue
            FROM quotes
            WHERE DATE_FORMAT(created_at, '%Y-%m') = ?
        ");
        $stmt->execute([$month]);
        $data = $stmt->fetch();
        $monthly_data[] = [
            'month' => date('M Y', strtotime($month . '-01')),
            'count' => $data['count'] ?? 0,
            'revenue' => $data['revenue'] ?? 0
        ];
    }

} catch (Exception $e) {
    $error_message = 'Veriler yüklenirken hata oluştu: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Nakliye Teklif Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
        }
        .stat-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">
                            <i class="fas fa-truck"></i><br>
                            Admin Panel
                        </h4>
                        <small class="text-white-50">Hoş geldiniz, <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></small>
                    </div>

                    <nav class="nav flex-column">
                        <a class="nav-link active" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                        <a class="nav-link" href="quotes.php">
                            <i class="fas fa-file-invoice me-2"></i> Teklifler
                        </a>
                        <a class="nav-link" href="customers.php">
                            <i class="fas fa-users me-2"></i> Müşteriler
                        </a>
                        <a class="nav-link" href="transport-modes.php">
                            <i class="fas fa-truck me-2"></i> Taşıma Modları
                        </a>
                        <a class="nav-link" href="cost-lists.php">
                            <i class="fas fa-file-excel me-2"></i> Maliyet Listeleri
                        </a>
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-cog me-2"></i> Ayarlar
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Çıkış
                        </a>
                    </nav>
                </div>
            </nav>

            <!-- Ana İçerik -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary">
                                <i class="fas fa-calendar"></i> Bu Ay
                            </button>
                        </div>
                        <a href="../index.php" class="btn btn-sm btn-primary" target="_blank">
                            <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                        </a>
                    </div>
                </div>

                <?php if (isset($error_message)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error_message) ?>
                </div>
                <?php endif; ?>

                <!-- İstatistik Kartları -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Toplam Teklif</h5>
                                        <span class="h2 font-weight-bold mb-0"><?= number_format($stats['total_quotes']) ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="stat-icon bg-primary">
                                            <i class="fas fa-file-invoice"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Bu Ay</h5>
                                        <span class="h2 font-weight-bold mb-0"><?= number_format($stats['monthly_quotes']) ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="stat-icon bg-success">
                                            <i class="fas fa-calendar-check"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Müşteriler</h5>
                                        <span class="h2 font-weight-bold mb-0"><?= number_format($stats['total_customers']) ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="stat-icon bg-info">
                                            <i class="fas fa-users"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Toplam Gelir</h5>
                                        <span class="h2 font-weight-bold mb-0"><?= formatPrice($stats['total_revenue']) ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="stat-icon bg-warning">
                                            <i class="fas fa-lira-sign"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Grafik ve Son Teklifler -->
                <div class="row">
                    <div class="col-lg-8 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-chart-line"></i> Aylık Teklif Grafiği</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="monthlyChart" height="100"></canvas>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-clock"></i> Son Teklifler</h5>
                            </div>
                            <div class="card-body p-0">
                                <div class="list-group list-group-flush">
                                    <?php foreach ($recent_quotes as $quote): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h6 class="mb-1"><?= htmlspecialchars($quote['quote_number']) ?></h6>
                                            <small><?= formatDate($quote['created_at']) ?></small>
                                        </div>
                                        <p class="mb-1"><?= htmlspecialchars($quote['first_name'] . ' ' . $quote['last_name']) ?></p>
                                        <small>
                                            <?= htmlspecialchars($quote['transport_mode']) ?> -
                                            <span class="text-success"><?= formatPrice($quote['final_price']) ?></span>
                                        </small>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Hızlı Aksiyonlar -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-bolt"></i> Hızlı Aksiyonlar</h5>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col-md-3 mb-3">
                                        <a href="quotes.php?status=pending" class="btn btn-outline-warning btn-lg w-100">
                                            <i class="fas fa-clock"></i><br>
                                            Bekleyen Teklifler
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="transport-modes.php" class="btn btn-outline-primary btn-lg w-100">
                                            <i class="fas fa-edit"></i><br>
                                            Şablonları Düzenle
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="settings.php" class="btn btn-outline-info btn-lg w-100">
                                            <i class="fas fa-cog"></i><br>
                                            Ayarlar
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="email-logs.php" class="btn btn-outline-success btn-lg w-100">
                                            <i class="fas fa-envelope-open"></i><br>
                                            E-posta Logları
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Aylık grafik
        const ctx = document.getElementById('monthlyChart').getContext('2d');
        const monthlyChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($monthly_data, 'month')) ?>,
                datasets: [{
                    label: 'Teklif Sayısı',
                    data: <?= json_encode(array_column($monthly_data, 'count')) ?>,
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.1)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>