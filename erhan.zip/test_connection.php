<?php
require_once 'config/database.php';

echo "Laragon MySQL bağlantısı test ediliyor...\n";

try {
    $database = new Database();
    $pdo = $database->getConnection();
    
    if ($pdo) {
        echo "✅ Veritabanı bağlantısı başarılı!\n";
        
        // Tabloları listele
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "\n📋 Mevcut tablolar:\n";
        foreach ($tables as $table) {
            echo "  - $table\n";
        }
        
        // Müşteri sayısını kontrol et
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM customers");
        $result = $stmt->fetch();
        echo "\n👥 Toplam müşteri sayısı: " . $result['count'] . "\n";
        
        // Teklif sayısını kontrol et
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM quotes");
        $result = $stmt->fetch();
        echo "📄 Toplam teklif sayısı: " . $result['count'] . "\n";
        
    } else {
        echo "❌ Veritabanı bağlantısı başarısız!\n";
    }
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage() . "\n";
}
?>
